INSERT INTO Television (PRODUCT_ID, BRAND, DISPLAY, PRICE , TV_TYPE, IS_COLOR) VALUES
  ('100', 'Samsung', 'OLED', 2999 ,'SmartTV' , true),
  ('101', 'LG', 'CRT', 2000 ,'Normal' , false);